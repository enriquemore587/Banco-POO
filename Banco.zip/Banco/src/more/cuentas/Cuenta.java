/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package more.cuentas;

import more.excepciones.SaldoInsuficienteException;

/**
 *
 * @author vergara
 */
public class Cuenta {
    
    private String numCuenta;
    
    private Ahorro ahorro;
    
    private Cheques cheques;

    
    
    //  metodo depositar
    public void depositar(int opcion, Double cantidad){
        //cheques
        if (opcion == 0) {
            this.cheques.setSaldo(
                    this.cheques.getSaldo()+cantidad
            );
        }
        else if (opcion == 1){//ahorro
            this.ahorro.setSaldo(
                    this.ahorro.getSaldo()+cantidad
            );
        }
    }
    
    // metodo retirar
    public void retirar(int opcion, Double cantidad) throws SaldoInsuficienteException{
        
        //cheques = 0 
        if (opcion == 0) {
            // 5 - 8
            // 5 - ¿?
            if (this.cheques.getSaldo()< cantidad) {
                throw  new SaldoInsuficienteException(cantidad);
            }
            //  5 - 4 = 1
            //  5 - 5 = 0
            else{
                this.cheques.setSaldo(
                    this.cheques.getSaldo() - cantidad
                );
                
            }
            
        }
        else if (opcion == 1){//ahorro
            // 5 - 9 = -4
            
            if (this.ahorro.getSaldo()< cantidad) {
                throw  new SaldoInsuficienteException(cantidad);
            }else{
                //10000.0 - 9000 = 1000
                // 5 - 5 = 0 
                // 5 - 4 = 1
                // 5 - 3 = 2
                // 5 - 2 = 3
                // 5 - 1 = 4
                this.ahorro.setSaldo(
                    this.ahorro.getSaldo() - cantidad
                );
                
            }
        }
        
    }
    public String getNumCuenta() {
        return numCuenta;
    }

    public void setNumCuenta(String numCuenta) {
        this.numCuenta = numCuenta;
    }

    public Ahorro getAhorro() {
        return ahorro;
    }

    public void setAhorro(Ahorro ahorro) {
        this.ahorro = ahorro;
    }

    public Cheques getCheques() {
        return cheques;
    }

    public void setCheques(Cheques cheques) {
        this.cheques = cheques;
    }
    
}
